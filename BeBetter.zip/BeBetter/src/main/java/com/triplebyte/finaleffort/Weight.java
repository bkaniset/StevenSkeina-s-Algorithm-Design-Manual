package com.triplebyte.finaleffort;

public class Weight {

double weight;	

public Weight(double weight)
{
	this.weight=weight;
}

}
