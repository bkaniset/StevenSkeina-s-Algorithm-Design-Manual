package com.triplebyte.finaleffort;


public class Bins {
	
	double remaining_weight;
    
	
	public Bins()
	{
		this.remaining_weight=1;
	}

}
