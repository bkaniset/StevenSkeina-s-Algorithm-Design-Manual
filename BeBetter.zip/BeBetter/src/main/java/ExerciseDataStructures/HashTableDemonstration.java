package ExerciseDataStructures;

public class HashTableDemonstration {

	
public static void main(String[] args)
{	
	HashTables ht=new HashTables(10);
	ht.add("jack", "Reacher");
	ht.add("jack", "valar");
	ht.add("kyle", "kuklinkski");
	ht.get("jack");
	
}
}
