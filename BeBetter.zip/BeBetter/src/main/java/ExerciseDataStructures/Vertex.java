package ExerciseDataStructures;

public class Vertex {

String name;

public Vertex()
{
	this.name=null;
	}

public Vertex(String name)
{
	this.name=name;
}
	
}
